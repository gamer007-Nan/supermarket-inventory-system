-- SCI22CSC138: AI-Powered Inventory Management & Anti-Theft System
-- MySQL schema

CREATE DATABASE IF NOT EXISTS inventory_theft_system
    CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE inventory_theft_system;

-- ---------------------------------------------------------------
-- Users & roles
-- ---------------------------------------------------------------
CREATE TABLE users (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    username        VARCHAR(64)  NOT NULL UNIQUE,
    email           VARCHAR(120) NOT NULL UNIQUE,
    password_hash   VARCHAR(255) NOT NULL,
    role            ENUM('staff', 'admin') NOT NULL DEFAULT 'staff',
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ---------------------------------------------------------------
-- Products & stock
-- ---------------------------------------------------------------
CREATE TABLE products (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    sku             VARCHAR(64)  NOT NULL UNIQUE,
    name            VARCHAR(255) NOT NULL,
    -- maps a product to the class label YOLOv8 was trained/fine-tuned on
    vision_class    VARCHAR(64)  NOT NULL,
    price           DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_vision_class (vision_class)
) ENGINE=InnoDB;

CREATE TABLE stock (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    product_id      INT NOT NULL,
    quantity        INT NOT NULL DEFAULT 0,
    updated_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
    UNIQUE KEY uq_stock_product (product_id)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------
-- Transactions (POS scans) — the "legitimate exit" evidence
-- ---------------------------------------------------------------
CREATE TABLE transactions (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    product_id      INT NOT NULL,
    user_id         INT NULL,            -- staff who processed it, if any
    quantity        INT NOT NULL DEFAULT 1,
    scanned_at      DATETIME(3) NOT NULL,
    register_id     VARCHAR(32) NULL,
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (product_id) REFERENCES products(id),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_txn_product_time (product_id, scanned_at)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------
-- Detections (YOLOv8 shelf-exit events) — the "physical exit" evidence
-- ---------------------------------------------------------------
CREATE TABLE detections (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    product_id      INT NULL,            -- resolved via vision_class, nullable if unmatched class
    vision_class    VARCHAR(64) NOT NULL,
    camera_id       VARCHAR(32) NOT NULL,
    confidence      FLOAT NOT NULL,
    detected_at     DATETIME(3) NOT NULL,
    -- correlation_status: pending until the engine evaluates it
    correlation_status ENUM('pending', 'matched', 'unmatched') NOT NULL DEFAULT 'pending',
    matched_transaction_id INT NULL,
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE SET NULL,
    FOREIGN KEY (matched_transaction_id) REFERENCES transactions(id) ON DELETE SET NULL,
    INDEX idx_det_product_time (product_id, detected_at),
    INDEX idx_det_status (correlation_status)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------
-- Alerts — generated only when a detection goes unmatched
-- ---------------------------------------------------------------
CREATE TABLE alerts (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    detection_id    INT NOT NULL,
    product_id      INT NULL,
    severity        ENUM('low', 'medium', 'high') NOT NULL DEFAULT 'medium',
    status          ENUM('open', 'acknowledged', 'resolved', 'false_positive') NOT NULL DEFAULT 'open',
    message         VARCHAR(255) NOT NULL,
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    resolved_by     INT NULL,
    resolved_at     TIMESTAMP NULL,
    FOREIGN KEY (detection_id) REFERENCES detections(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE SET NULL,
    FOREIGN KEY (resolved_by) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_alert_status (status)
) ENGINE=InnoDB;
